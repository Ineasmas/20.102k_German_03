﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20._102k_German_03
{
    class Helper
    {
        private static Entity.Entities SFEntities;

        public static Entity.Entities GetContext()
        {
            if (SFEntities == null)
                SFEntities = new Entity.Entities();
            return SFEntities;
        }
    }
}
